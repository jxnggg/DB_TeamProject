<HTML>
<HEAD>
<META http-equiv="content-type" content="text/html; charset=utf-8">
</HEAD>
<BODY>

<h1>  환자  관리시스템  </h1>

<FORM METHOD="get" ACTION="Resident_registration_number_result_DH.php">
-환자 조회(주민 번호) : <INPUT TYPE = "text" NAME = "Resident registration number">
<INPUT TYPE="submit" VALUE="검색">
</FORM>
<FORM METHOD="get" ACTION="Record_of_vaccination_result_DH.php"> </a>  <br><br>
-환자 조회(백신 기록) : <INPUT TYPE = "text" NAME = "Record of vaccination">
<INPUT TYPE="submit" VALUE="검색">
</FORM>
<FORM METHOD="get" ACTION="Date_of_1st_vaccination_result_DH.php"> </a>  <br><br>
-환자 조회(백신 1차 접종일) : <INPUT TYPE = "text" NAME = "Date of 1st vaccination">
<INPUT TYPE="submit" VALUE="검색">
</FORM>
<FORM METHOD="get" ACTION="Date_of_2nd_vaccination_result_DH.php"> </a>  <br><br>
-환자 조회(백신 2차 접종일) : <INPUT TYPE = "text" NAME = "Date of 2nd vaccination">
<INPUT TYPE="submit" VALUE="검색">
</FORM>
<FORM METHOD="get" ACTION="Side_effects_of_vaccination_result_DH.php"> </a>  <br><br>
-환자 조회(백신 부작용) : <INPUT TYPE = "text" NAME = "Side effects of vaccination">
<INPUT TYPE="submit" VALUE="검색">
</FORM>
<FORM METHOD="get" ACTION="Vaccine_number_result_DH.php"> </a>  <br><br>
-환자 조회(백신 번호) : <INPUT TYPE = "text" NAME = "Vaccine number">
<INPUT TYPE="submit" VALUE="검색">
</FORM>
<a  href='insert_DH.php'> -  신규 환자  등록 </a>  <br><br>
<a  href='Daegu_main.html'> -  초기 화면 </a>  <br><br>
        

</BODY>
</HTML>
