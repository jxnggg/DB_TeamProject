<HTML>
<HEAD>
<META http-equiv="content-type" content="text/html; charset=utf-8">
</HEAD>
<BODY>

<h1>  신규  환자 정보  입력  </h1>
<FORM  METHOD="post"    ACTION="insert_result_DH.php">
주민번호  : <INPUT  TYPE   ="text" NAME="Resident_registration_number"><br>
입원일 :   <INPUT  TYPE  ="text" NAME="Hospitalization_date">    <br>
코로나 검사 일자  : <INPUT  TYPE   ="text" NAME= "Date_of_the_COVID19_test">   <br>
백신 종류  :   <INPUT  TYPE   ="text" NAME="Record_of_vaccination"><br>

         <BR><BR>
         <INPUT  TYPE="submit"    VALUE="환자  입력">
  </FORM>

<br><br> <a href = 'patient_DH.php'> <--환자 관리 시스템</a>

</BODY>
</HTML>