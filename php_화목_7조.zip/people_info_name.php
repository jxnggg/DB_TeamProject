<FORM METHOD="get" ACTION="people_info_name_result.php"><strong>국민 정보 조회(이름) :</strong> <INPUT TYPE ="text" NAME="name" size=30 style="width:300px; height:30px;">
      <INPUT TYPE="submit" VALUE="조회"><br><br>


