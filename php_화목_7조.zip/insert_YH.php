<HTML>
<HEAD>
<META http-equiv="content-type" content="text/html; charset=utf-8">
</HEAD>
<BODY>

<h1>  신규  환자 정보  입력  </h1>
<FORM  METHOD="post"    ACTION="insert_result_YH.php">
주민번호  : <INPUT  TYPE   ="text" NAME="Resident_registration_number"><br>
입원일 :   <INPUT  TYPE  ="text" NAME="Hospitalization_date">    <br>
코로나 검사 일자  : <INPUT  TYPE   ="text" NAME= "Date_of_the_COVID19_test">   <br>
백신 종류  :   <INPUT  TYPE   ="text" NAME="Record_of_vaccination"><br>
백신 1차 접종일 : <INPUT  TYPE   ="text" NAME="Date_of_1st_vaccination"><br>
백신 2차 접종일 : <INPUT  TYPE   ="text" NAME="Date_of_2nd_vaccination"><br>
백신 부작용 : <INPUT  TYPE   ="text" NAME="Side_effects_of_vaccination"><br>
백신 번호 : <INPUT  TYPE   ="text" NAME="Vaccine_number"><br>
         <BR><BR>
         <INPUT  TYPE="submit"    VALUE="환자  입력">
  </FORM>

<br><br> <a href = 'patient_YH.php'> <--환자 관리 시스템</a>

</BODY>
</HTML>